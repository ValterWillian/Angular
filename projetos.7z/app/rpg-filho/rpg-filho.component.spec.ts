import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RpgFilhoComponent } from './rpg-filho.component';

describe('RpgFilhoComponent', () => {
  let component: RpgFilhoComponent;
  let fixture: ComponentFixture<RpgFilhoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RpgFilhoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RpgFilhoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
