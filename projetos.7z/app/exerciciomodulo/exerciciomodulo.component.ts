import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exerciciomodulo',
  templateUrl: './exerciciomodulo.component.html',
  styleUrls: ['./exerciciomodulo.component.css']
})
export class ExerciciomoduloComponent implements OnInit {

  Pessoa = {
    nome: "Valter", 
    sexo: "Masculino"
  }

  constructor() { }

  ngOnInit() {
  }

}
