import { TestBed, inject } from '@angular/core/testing';

import { TimesService } from './times.service';
import { FORMERR } from 'dns';

describe('TimesService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TimesService]
    });
  });

  it('should be created', inject([TimesService], (service: TimesService) => {
    expect(service).toBeTruthy();
  }));
});
