import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ngif',
  templateUrl: './ngif.component.html',
  styleUrls: ['./ngif.component.css']
})
export class NgifComponent implements OnInit {

render : boolean =true;
aba: string = "";

  constructor() { }

changeIsRender (){

  this.render = !this.render;
}
cliqueRPG()
{ 
  this.aba = "RPG";
  console.log(this.aba);
}

cliqueCores()
{ 
  this.aba = "Cores";
  console.log(this.aba);
}

cliqueCard()
{ 
  this.aba = "Card";
  console.log(this.aba);
}

cliqueValidacao()
{ 
  this.aba = "Validacao";
  console.log(this.aba);
}
cliqueSalario()
{ 
  this.aba = "Salario";
  console.log(this.aba);
}
cliquePipe()
{ 
  this.aba = "Pipe";
  console.log(this.aba);
}
  ngOnInit() {  }

} 
