import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';

@Component({
selector: 'app-time',
templateUrl: './time.component.html',
styleUrls: ['./time.component.css']
})
export class TimeComponent implements OnInit, OnDestroy {
meuTime: string;
sub: Subscription;
constructor(private route: ActivatedRoute) {

// console.log(route);
// this.meuTime = this.route.snapshot.params['meuTime'];
// console.log(this.meuTime);
}

ngOnInit() {

this.sub = this.route.params.subscribe(params => { this.meuTime = params['meuTime']; });
console.log(this.meuTime);
}

ngOnDestroy() {

this.sub.unsubscribe();
}

} 
