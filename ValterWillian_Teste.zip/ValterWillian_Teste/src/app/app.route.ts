import { Routes } from "@angular/router";
import { HomeComponent } from "./home/home.component";
import { SobreComponent } from "./sobre/sobre.component";
import { CorridaComponent } from "./corrida/corrida.component";
import { CadastroComponent } from "./cadastro/cadastro.component";

export const ROUTES: Routes = [

    {path: '', component: HomeComponent},
    {path: 'sobre', component: SobreComponent},
    {path: 'corrida', component: CorridaComponent},
    {path: 'cadastro', component: CadastroComponent}
];