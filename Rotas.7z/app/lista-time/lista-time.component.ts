import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lista-time',
  templateUrl: './lista-time.component.html',
  styleUrls: ['./lista-time.component.css']
})
export class ListaTimeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
