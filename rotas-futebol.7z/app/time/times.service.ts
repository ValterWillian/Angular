import { Router } from '@angular/router';
import { Injectable } from '@angular/core';
import { Time } from '../time/time';


@Injectable()
export class TimesService {

  times: Time[] = [{

    nome: 'Corinthians',
    tecnico: 'Tite',
    isLibertadores: true,
    pontuacao: 45

  },
  {
    nome: 'Palmeiras',
    tecnico: 'Machado 98',
    isLibertadores: true,
    pontuacao: 41
  },

  {
    nome: 'Ceara',
    tecnico: 'Machado 91',
    isLibertadores: false,
    pontuacao: 42
  }
  ];

  getTimes() {

    return this.times;
  }
  addTime(time) {
    this.times.push(time);
  }
  
 
  getTimeByName(nome: string): Time {
    for (let i in this.times) {

      if (nome == this.times[i].nome) {
        return this.times[i];

      }
      this.router.navigate(['timeNotFound']);
    }
    
  }





  constructor(private router : Router) { }

}
