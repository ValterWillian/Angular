import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-vida-filho',
  templateUrl: './vida-filho.component.html',
  styleUrls: ['./vida-filho.component.css']
})
export class VidaFilhoComponent implements OnInit {

  @Input() vida: number;
  @Output() eventoMorte = new EventEmitter;
  danoinformado: number;
  morreu: boolean;

  dano() {
    if (this.vida - this.danoinformado > 0) {
      let danotomado = this.vida - this.danoinformado;
      this.vida = danotomado;
    } else {
      this.vida = 0;
      this.morreu = true;
      this.eventoMorte.emit(this.morreu);

    }


    console.log(this.vida);

  }



  constructor() { }

  ngOnInit() {
  }

}
