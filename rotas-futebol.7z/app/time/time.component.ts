import { TimesService } from '../time/times.service';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import { Time } from '../time/time';

@Component({
    selector: 'app-time',
    templateUrl: './time.component.html',
    styleUrls: ['./time.component.css']
})
export class TimeComponent implements OnInit, OnDestroy {
    meuTime: Time;
    sub: Subscription;
    constructor(private route: ActivatedRoute,
        private timeServ: TimesService) {

        // console.log(route);
        // this.meuTime = this.route.snapshot.params['meuTime'];
        // console.log(this.meuTime);
    }

    ngOnInit() {
        this.sub = this.route.params.subscribe(params => {
            this.meuTime = this.timeServ.getTimeByName(params['meuTime']);

        });
    }

    ngOnDestroy() {

        this.sub.unsubscribe();
    }

} 
