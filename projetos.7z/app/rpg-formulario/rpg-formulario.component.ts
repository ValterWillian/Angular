import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rpg-formulario',
  templateUrl: './rpg-formulario.component.html',
  styleUrls: ['./rpg-formulario.component.css']
})
export class RpgFormularioComponent implements OnInit {

  Heroi={
      nome: "",
      apelido:"",
      raca: "",
      classe: "",
      arma: ""

  }


  criarHeroi (nomeHeroi, apelidoHeroi, racaHeroi, classeHeroi, armaHeroi){

  this.Heroi.nome = nomeHeroi;
  this.Heroi.apelido =apelidoHeroi;
  this.Heroi.raca =racaHeroi;
  this.Heroi.classe =classeHeroi;   
  this.Heroi.arma = armaHeroi;
  

  console.log(this.Heroi.nome);
  console.log(this.Heroi.apelido);
  console.log(this.Heroi.classe);
  console.log(this.Heroi.raca);
  console.log(this.Heroi.arma);
 
}
  constructor() { }

  


  ngOnInit() {
  }

}
