
import { Route, Router } from '@angular/router';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { MaterializeModule } from 'angular2-materialize';
import { FormsModule } from '@angular/forms';
  

import { AppComponent } from './app.component';
import { Ex1Component } from './ex1/ex1.component';
import { Exercicio2Component } from './exercicio2 - filmes/exercicio2.component';
import { Exercicio3Component } from './exercicio3 - cores/exercicio3.component';
import { Exercicio4Component } from './exercicio4 - ngModel/exercicio4.component';
import { Exercicio5Component } from './exercicio5/exercicio5.component';
import { RpgPaiComponent } from './rpg-pai/rpg-pai.component';
import { RpgFilhoComponent } from './rpg-filho/rpg-filho.component';
import { RpgFormularioComponent } from './rpg-formulario/rpg-formulario.component';
import {VidaComponent} from './vida/vida.component';
import {VidaFilhoComponent } from './vida-filho/vida-filho.component';
import { VidaNetoComponent } from './vida-neto/vida-neto.component';
import { BotoesComponent } from './botoes/botoes.component';
import { RadioComponent } from './radio/radio.component';
import { CardComponent } from './card/card.component';
import { NgifComponent } from './ngif/ngif.component';
import { SalarioComponent } from './salario/salario.component';
import { ExercicioDiretivaDirective } from './shared/exercicio-diretiva.directive';
import { ArcoirisDirective } from './shared/arcoiris.directive';
import { DadosComponent } from './rpg-formulario/dados/dados.component';
import { DadosService } from './shared/dados/dados.service';
import { PipePipe } from './shared/pipe.pipe';
import { PipeComponent } from './pipe/pipe.component';
import { TeleComponent } from './tele/tele.component';
import { Pipe2Pipe } from './pipe2.pipe';
import { ServicesService } from './tele/services.service';
import { routing } from './ngif.1 - Rotas/app.routing';



@NgModule({
  declarations: [
    AppComponent,
    Ex1Component,
    Exercicio2Component,
    Exercicio3Component,
    Exercicio4Component,
    Exercicio5Component,
    RpgPaiComponent,
    RpgFilhoComponent,
    RpgFormularioComponent,
    VidaComponent,
    VidaFilhoComponent,
    VidaNetoComponent,
    BotoesComponent,
    RadioComponent,
    CardComponent,
    NgifComponent,
    SalarioComponent,
    ExercicioDiretivaDirective,
    ArcoirisDirective,
    DadosComponent,
    PipePipe,
    PipeComponent,
    TeleComponent,
    Pipe2Pipe,
    NgifComponent,
   
    

  ],
  imports: [
    BrowserModule,
    MaterializeModule,
    FormsModule,
    routing
  ],
  providers: [DadosService,ServicesService,],
  bootstrap: [AppComponent]
})
export class AppModule { }
