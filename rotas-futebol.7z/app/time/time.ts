
export interface Time {

    nome: string;
    tecnico: string;
    isLibertadores : boolean;
    pontuacao : number;

}