import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-vida',
  templateUrl: './vida.component.html',
  styleUrls: ['./vida.component.css']
})
export class VidaComponent implements OnInit {

  morreu = false;
  vidapersonagem: number = 100;
  msg = 'NAO MORREU';

  mata(eventomorreu) {
    this.morreu = eventomorreu;

    if (this.morreu) {

      this.msg = "MORREU";
    }
    else {

      this.msg = 'NAO MORREU'
    }
  }


  constructor() { }

  ngOnInit() {
  }

}
