import { MusicasService } from './../musicas.service';
import { Component, OnInit } from '@angular/core';
import { Musica } from '../musica';

@Component({
  selector: 'app-lista',
  templateUrl: './lista.component.html',
  styleUrls: ['./lista.component.css']
})
export class ListaComponent implements OnInit {

  constructor(private musicasServices: MusicasService) { }

  musicas: Musica[];

  ngOnInit() {

    this.musicas = this.musicasServices.musicas;
  }

}
