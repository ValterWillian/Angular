import { Pessoa } from 'app/Pessoa';
import { CadastroService } from 'app/cadastro.service';
import { Component, OnInit, OnDestroy } from '@angular/core';


@Component({
  selector: 'mt-cadastro',
  templateUrl: './cadastro.component.html',
  styleUrls: ['./cadastro.component.css']
})
export class CadastroComponent implements OnInit {

  novapessoa: Pessoa;

  constructor(private servico : CadastroService) { }

     
addPessoa(nome,sobrenome,cpf,email,telefone) {
this.novapessoa= { nome : nome,sobrenome: sobrenome,cpf: cpf,email :email,telefone : telefone};
this.servico.addPessoas(this.novapessoa);
}

ngOnInit() {

}

}
