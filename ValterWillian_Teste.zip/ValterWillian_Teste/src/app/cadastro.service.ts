import { Injectable } from '@angular/core';
import { Pessoa } from './Pessoa';
import { Motorista } from './Motorista';

@Injectable()
export class CadastroService {

  pessoa: Pessoa;
  motorista: Motorista = {
    nome :'Antonio da Silva',
    telefone: 11970418803,
    Nomedocarro: 'Renault Clio - Branco'
  }

    
    getPessoas () {
    
      return this.pessoa;
    }

    addPessoas (pessoa) {
      this.pessoa = pessoa;
    }

  

  constructor() { }



}
