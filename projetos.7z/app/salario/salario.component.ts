import { Component, OnInit, } from '@angular/core';

@Component({
  selector: 'app-salario',
  templateUrl: './salario.component.html',
  styleUrls: ['./salario.component.css']
})
export class SalarioComponent implements OnInit {



   Funcionario = [
     {
    Nome: "Kevin",
    Sobrenome: "Mitnick",
    Id: 2,
    Salario: 2.001,
    Sede: "SP"
},
{
    Nome: "Taco",
    Sobrenome: "Teco",
    Id: 4,
    Salario: 4.001,
    Sede: "BA"
},
{
  Nome: "Teccco",
  Sobrenome: "Tecdsfgo",
  Id: 4322,
  Salario: 4.3201,
  Sede: "BA"
},

{
  Nome: "Sorriso",
  Sobrenome: "Colgate",
  Id: 8460,
  Salario: 2.121,
  Sede: "SP"
  
}]; 


  constructor() { }

  ngOnInit() {
  }

}

