import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExerciciomoduloComponent } from './exerciciomodulo.component';

describe('ExerciciomoduloComponent', () => {
  let component: ExerciciomoduloComponent;
  let fixture: ComponentFixture<ExerciciomoduloComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExerciciomoduloComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExerciciomoduloComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
