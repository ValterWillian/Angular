import { Injectable } from '@angular/core';

@Injectable()
export class ServicesService {

  constructor() { }
    
    getFuncionarios() {
      return [
  {
      nome:"HP",
      preco: 5000,
      codigo: "34",
      descricao: "Computador Hp Elitedesk 800 G2, Intel Core I7-6700, Hd 1tb, Ram 8gb, Windows 10 Pro",
      data_val: new Date(),
        },
        {
        nome:"Dell",
        preco: 9000,
        codigo: "12",
        descricao: "Computador Dell XPS-8900-A50 Intel Core i7 24GB (2G de Memória Dedicada) 2TB 256GB SSD Windows 10",
        data_val: new Date(),
          },
          {
            nome:"Dell",
            preco: 1500,
            codigo: "321",
            descricao: "Computador Dell Intel Core i7 4GB 256GB SSD Windows 10",
            data_val: new Date(),
              },
              {
                nome:"Dell",
                preco: 9000,
                codigo: "12",
                descricao: "Computador Dell XPS-8900-A50 Intel Core i7 24GB (2G de Memória Dedicada) 2TB 256GB SSD Windows 10",
                data_val: new Date(),
                  },
                  {
                    nome:"Dell",
                    preco: 1500,
                    codigo: "321",
                    descricao: "Computador Dell Intel Core i7 4GB 256GB SSD Windows 10",
                    data_val: new Date(),
                      }
            ];

}
}
