import { ExercicioDiretivaDirective } from './exercicio-diretiva.directive';

describe('ExercicioDiretivaDirective', () => {
  it('should create an instance', () => {
    const directive = new ExercicioDiretivaDirective();
    expect(directive).toBeTruthy();
  });
});
