import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VidaNetoComponent } from './vida-neto.component';

describe('VidaNetoComponent', () => {
  let component: VidaNetoComponent;
  let fixture: ComponentFixture<VidaNetoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VidaNetoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VidaNetoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
