import { TestBed, inject } from '@angular/core/testing';

import { MusicasService } from './musicas.service';

describe('MusicasService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MusicasService]
    });
  });

  it('should be created', inject([MusicasService], (service: MusicasService) => {
    expect(service).toBeTruthy();
  }));
});
