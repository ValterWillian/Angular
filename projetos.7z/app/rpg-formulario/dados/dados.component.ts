import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import {DadosService} from './../../shared/dados/dados.service';

@Component({
  selector: 'app-dados',
  templateUrl: './dados.component.html',
  styleUrls: ['./dados.component.css']
})
export class DadosComponent implements OnInit {
  
  numDados: number;
  numLados: number;
  result = 0;

  constructor(private fodase: DadosService) { }


RodarDado(dados4, dados6, dados10) {

  this.result = 0;
for (let i = 0; i < this.numDados; i++) {
this.result += this.fodase.dados4()
  console.log (this.result);
}
 {
this.result = 0;
for (let i = 0; i < this.numDados; i++) {
this.result += this.fodase.dados6()
  console.log (this.result);
}}
{ 
  this.result = 0;
  for (let i = 0; i < this.numDados; i++) {
  this.result += this.fodase.dados10()
    console.log (this.result);
  }}
  
}

  ngOnInit() { }


}





