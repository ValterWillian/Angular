export interface Motorista {

    
    nome: string;
    telefone : number;
    Nomedocarro: string;
    
}