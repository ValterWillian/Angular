import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-formvalidacao',
  templateUrl: './formvalidacao.component.html',
  styleUrls: ['./formvalidacao.component.css']
})
export class FormvalidacaoComponent implements OnInit {
  loginuser: string;
  senhauser: string;
  classe: string;

  validarLogin() {
    console.log(this.loginuser);
    if (!this.loginuser.match('[a-zA-Z]')) {
      alert('Verifique o campo novamente');
    }
  }

  validarSenha() {
    console.log(this.senhauser);
    if (!this.senhauser.match('^(?=.*[0-9])(?=.*[a-z])(?=.*[@#$%^&+=.\-_*])([a-zA-Z0-9@#$%^&+=*.\-_]){3,}$')) {
      alert('Verifique o campo novamente');
    }
  }


  constructor() { }

  ngOnInit() {
  }

}
