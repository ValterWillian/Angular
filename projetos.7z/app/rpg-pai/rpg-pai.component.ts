import { Component, OnInit,Input,Output,EventEmitter } from '@angular/core';


@Component({
  selector: 'app-rpg-pai',
  templateUrl: './rpg-pai.component.html',
  styleUrls: ['./rpg-pai.component.css']
})
export class RpgPaiComponent implements OnInit {

morreu = false;
vidapersonagem: number = 100;
msg = 'NAO MORREU';

mata(eventomorreu) {
this.morreu = eventomorreu;

if (this.morreu) {

this.msg = "MORREU";
}else {

this.msg = 'NAO MORREU'
}}

  constructor() { }

  ngOnInit() {
  }

}
