
export interface Musica {

    id: number;
    nome: string;
    artista: string;
    genero: string;
    ano : number;
    
}