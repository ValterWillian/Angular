import { Directive, HostListener, ElementRef, Renderer, HostBinding, Input } from '@angular/core';

@Directive({
  selector: '[appArcoiris]'
})
export class ArcoirisDirective {
  
  possibleColors = ['green', 'red', 'yellow'];
  fontstyle = [ 'Arial','Times New Roman','Comic Sans','COURIER'];
  @Input ('cordeFundo') corInicial = ''; 
  @HostBinding('style.color') color: string;
  @HostBinding('style.background-color') backgroundColor : string;

  @HostListener('keydown') newColor() {
    const colorPick = Math.floor(Math.random() * this.possibleColors.length);

    this.color =  this.color = this.possibleColors[colorPick];
  }

  @HostBinding ('style.font-family') fontFamily : string ;
  @HostBinding ('style.font-size') fontSize : string ;

  @HostListener ('keyup') newFont (){
    const fontPick = Math.floor(Math.random() * this.fontstyle.length);

    this.fontFamily =  this.fontSize = this.fontstyle[fontPick];
  }
  
}