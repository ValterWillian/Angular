export interface Pessoa {

    
    nome: string;
    sobrenome: string;
    cpf: number;
    email: string;
    telefone : number;
    
}