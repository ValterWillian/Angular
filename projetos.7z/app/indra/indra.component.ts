import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-indra',
  templateUrl: './indra.component.html',
  styleUrls: ['./indra.component.css']
})
export class IndraComponent implements OnInit {
  nomeclasse = "marcabranco";
  imagemsegunda = "./assets/segunda.jpg";
  imagemcorra = "./assets/corra.jpg";
  imagempantera = "./assets/pantera.jpg";
  imagemritmo = "./assets/ritmo.jpg";

  marcatexto() {
    this.nomeclasse = 'marcatexto';
  }

  desmarcatexto() {
    this.nomeclasse = 'marcabranco';
  }

  constructor() { }

  ngOnInit() {
  }
}
