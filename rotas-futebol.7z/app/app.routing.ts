
import { RouterModule, Routes } from '@angular/router';

import { ListaTimeComponent } from './lista-time/lista-time.component';
import { JogadorComponent } from './jogador/jogador.component';
import { HomeComponent } from './../../../rotas2/src/app/home/home.component';
import { ModuleWithProviders, NgModule } from '@angular/core';
import { TimeComponent } from './time/time.component';
import { DetalheTimeComponent } from './detalhe-time/detalhe-time.component';

const APP_ROUTES: Routes = [

    {path: '', component:  HomeComponent },
    {path: 'jogador', component: JogadorComponent },
    {path: 'lista', component: ListaTimeComponent },
    {path: 'timeNotFound', component: DetalheTimeComponent },
    {path: 'time/:meuTime', component: TimeComponent},

];

// export const routing: ModuleWithProviders = RouterModule.forRoot(APP_ROUTES);

@NgModule({ 
    imports:[
        RouterModule.forRoot(APP_ROUTES)
        ],
        exports:[RouterModule]
        })
        export class AppRoutingModule{}         