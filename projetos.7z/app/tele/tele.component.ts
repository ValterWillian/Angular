import { Component, OnInit } from '@angular/core';
import { ServicesService } from './services.service';

@Component({
  selector: 'app-tele',
  templateUrl: './tele.component.html',
  styleUrls: ['./tele.component.css']
})
export class TeleComponent implements OnInit {

  constructor ( private services: ServicesService){}

  filtro: string;
  value : string;
  Funcionario: any;
  FuncionarioF: any;
   
  filtrar() {

  if (this.Funcionario.length == 0 || this.filtro == undefined) {
  this.FuncionarioF = this.Funcionario;
  } else {
  let acc = [];
  for (let i of this.Funcionario) {
  acc.push(i.Nome);}
  
  
  let r = [];
  acc = acc.filter(valor => valor.indexOf(this.filtro) != -1);
  for (let i in this.Funcionario) {
  for (let y in acc) {
  if (acc[y] == this.Funcionario[i].Nome) {
  r.push(this.Funcionario[i]);
  }}
  }
  this.FuncionarioF = r;
  }} 
             
    

  ngOnInit() { }

}
