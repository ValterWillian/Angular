import { TimesService } from './../times.service';
import { Component, OnInit } from '@angular/core';
import { Time } from '../time/time';

@Component({
  selector: 'app-lista-time',
  templateUrl: './lista-time.component.html',
  styleUrls: ['./lista-time.component.css']
})
export class ListaTimeComponent implements OnInit {

  constructor(private TimesService: TimesService) { }

  times: Time[];



  ngOnInit() {

    this.times = this.TimesService.getTimes();
  }


}
