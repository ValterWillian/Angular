import { Injectable } from '@angular/core';
import { Time } from './time/time';


@Injectable()
export class TimesService {
times: Time[]= [{

nome: "Corinthians",
tecnico: "Tite",
isLibertadores: true,
pontuacao: 45

},
{
nome: "Palmeiras",
tecnico: "Machado 98",
isLibertadores: true,
pontuacao: 41
},

{
  nome: "Fortaleza",
  tecnico: "Machado 91",
  isLibertadores: true,
  pontuacao: 42
  },
]
getTimes (){

  return this.times;
}
addTime (time) {
this.times.push(time);

}






  constructor() { }

}
