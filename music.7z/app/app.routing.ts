import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';

import { HomeComponent } from './home/home.component';
import { ListaComponent } from './lista/lista.component';
import { MusicasComponent } from './musicas/musicas.component';

const APP_ROUTES: Routes = [

    {path: '', component:  HomeComponent },
    {path: 'lista', component: ListaComponent },
    {path: 'musica/:minhaMusica', component: MusicasComponent},
 ];

 export const routing: ModuleWithProviders = RouterModule.forRoot(APP_ROUTES);