import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JumanjinterpolacaoComponent } from './jumanjinterpolacao.component';

describe('JumanjinterpolacaoComponent', () => {
  let component: JumanjinterpolacaoComponent;
  let fixture: ComponentFixture<JumanjinterpolacaoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JumanjinterpolacaoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JumanjinterpolacaoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
