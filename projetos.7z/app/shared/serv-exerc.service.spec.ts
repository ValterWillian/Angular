import { TestBed, inject } from '@angular/core/testing';

import { ServExercService } from './serv-exerc.service';

describe('ServExercService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ServExercService]
    });
  });

  it('should be created', inject([ServExercService], (service: ServExercService) => {
    expect(service).toBeTruthy();
  }));
});
