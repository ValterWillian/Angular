import { ActivatedRoute, Router } from '@angular/router';
import { TimesService } from './../times.service';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Time } from '../time/time';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-lista-time',
  templateUrl: './lista-time.component.html',
  styleUrls: ['./lista-time.component.css']
})
export class ListaTimeComponent implements OnInit {

  constructor(private timesServices: TimesService,
              private route: ActivatedRoute,
            private router: Router) { }

  times: Time[];
  sub : Subscription;
  query ;

  ngOnInit() {

    this.times = this.timesServices.getTimes();
    this.sub = this.route.queryParams.subscribe( 
      dobrinhas =>  {this.query = dobrinhas ['regiao']}
    );
  console.log(this.query);
  }

OnDestroy () {

  this.sub.unsubscribe();
}

alterarRegiaoSul(regiao) {
  this.query=regiao;
  this.router.navigate(['/lista'], { queryParams: { regiao: 'sul' } })

}
alterarRegiaoCentro(regiao) {
  this.query=regiao;
  this.router.navigate(['/lista'], { queryParams: { regiao: 'centro' } })
}
alterarRegiaoLeste(regiao) {
  this.query=regiao;
  this.router.navigate(['/lista'], { queryParams: { regiao: 'leste' } })
}
}
