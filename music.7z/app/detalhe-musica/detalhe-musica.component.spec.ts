import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetalheMusicaComponent } from './detalhe-musica.component';

describe('DetalheMusicaComponent', () => {
  let component: DetalheMusicaComponent;
  let fixture: ComponentFixture<DetalheMusicaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetalheMusicaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetalheMusicaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
