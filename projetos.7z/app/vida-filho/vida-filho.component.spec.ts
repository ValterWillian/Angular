import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VidaFilhoComponent } from './vida-filho.component';

describe('VidaFilhoComponent', () => {
  let component: VidaFilhoComponent;
  let fixture: ComponentFixture<VidaFilhoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VidaFilhoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VidaFilhoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
