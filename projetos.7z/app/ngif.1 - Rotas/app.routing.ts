
import { CardComponent } from './../card/card.component';

import { Routes, RouterModule } from '@angular/router';


import { ModuleWithProviders } from '@angular/core';
import { Exercicio3Component } from '../exercicio3 - cores/exercicio3.component';
import { RpgFormularioComponent } from '../rpg-formulario/rpg-formulario.component';
import { SalarioComponent } from '../salario/salario.component';


const APP_ROUTES: Routes = [

    {path: 'Cores', component:  Exercicio3Component },
    {path: 'Card,', component: CardComponent },
    {path: 'RPG', component: RpgFormularioComponent },
    {path: 'Salario',component: SalarioComponent},


]
export const routing: ModuleWithProviders = RouterModule.forRoot(APP_ROUTES);