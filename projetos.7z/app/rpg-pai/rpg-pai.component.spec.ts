import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RpgPaiComponent } from './rpg-pai.component';

describe('RpgPaiComponent', () => {
  let component: RpgPaiComponent;
  let fixture: ComponentFixture<RpgPaiComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RpgPaiComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RpgPaiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
