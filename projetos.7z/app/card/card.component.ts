import { Component, OnInit, ElementRef,ViewChild } from '@angular/core';


@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css']
})
export class CardComponent implements OnInit {
  contador = 0;
  

  @ViewChild('numeros') campo: ElementRef;
  

  incrementar(){
    this.campo.nativeElement.value++;

  }
  desincrementar(){
    this.campo.nativeElement.value--;
  }


  @ViewChild('tempo') cronograma: ElementRef;



  
  start () {

    this.cronograma.nativeElement.value++;
    

  }

  stop () {

    this.cronograma.nativeElement.value--;

  }
  constructor() {
   
  }

  ngOnInit() { }
  }