import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListaTimeComponent } from './lista-time.component';

describe('ListaTimeComponent', () => {
  let component: ListaTimeComponent;
  let fixture: ComponentFixture<ListaTimeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListaTimeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListaTimeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
