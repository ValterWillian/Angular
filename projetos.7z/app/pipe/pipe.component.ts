import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipe',
  templateUrl: './pipe.component.html',
  styleUrls: ['./pipe.component.css']
})
export class PipeComponent implements OnInit {

  constructor() { }

  
produtos = {
  
nome: "Cafe do centro",
peso: 250,
preco: 18.25,
codigo: "234543234",
descricao: "xsxxx dsd sdsdsdsdssdsaxa",
data_val: new Date(),
cpf: "12345678901",

}

  ngOnInit() {}

}
