

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ex1',
  templateUrl: './ex1.component.html',
  styleUrls: ['./ex1.component.css']
})
export class Ex1Component {
  img = './assets/praia.jpeg';
  img2 = './assets/teste1.jpg';

 x = 'apresentar';
 pessoa = {
 nome : ' José Otávio',
 sexo : 'M'
  };
  constructor() {

    }

    sexoPessoa (sexo): string {
      sexo = this.pessoa.sexo;
      if (sexo === 'M') {
      return ('Senhor: ');
      } else {
      return ('Senhora: ');
      }
        }

        NomeC (nome): string {
          nome = this.pessoa.nome;
          return nome;


  }

    mostrar () {
      this.x = '';

    }
}
