import { Directive, ElementRef, Renderer, HostListener } from '@angular/core';

@Directive({
  selector: ' [appExercicioDiretiva]'
})
export class ExercicioDiretivaDirective {

  @HostListener ('mouseover') teste (){

  this.renderer.setElementStyle(this.elementRef.nativeElement, 'color', 'red');
  }
  @HostListener ('mouseout') teste1 (){

    this.renderer.setElementStyle(this.elementRef.nativeElement, 'color', 'blue');
    }
 
  
   // constructor(private elementRef: ElementRef ) {

  //   this.elementRef.nativeElement.style.color = "red";
  //   this.elementRef.nativeElement.style.backgroundColor = "lightblue";
  //   this.elementRef.nativeElement.style.fontSize = "24px";
  //   this.elementRef.nativeElement.style.fontFamily = "Franklin Gothic Medium";
  //   this.elementRef.nativeElement.style.textAlign = "Center";
  //   this.elementRef.nativeElement.style.border = "1.2px solid black" ;  }


  constructor (private elementRef: ElementRef, private renderer : Renderer ){

  this.renderer.setElementStyle(this.elementRef.nativeElement, 'backgroundColor', 'lightblue');
  this.renderer.setElementStyle(this.elementRef.nativeElement,  'fontSize', '24px');
  this.renderer.setElementStyle(this.elementRef.nativeElement, 'textAlign', 'center');
  this.renderer.setElementStyle(this.elementRef.nativeElement,  'border', '1.2px solid black');}


}
