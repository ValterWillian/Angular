import { MusicasService } from './../musicas.service';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-detalhe-musica',
  templateUrl: './detalhe-musica.component.html',
  styleUrls: ['./detalhe-musica.component.css']
})
export class DetalheMusicaComponent implements OnInit,OnDestroy {
 

  minhaMusica: Musica ;
  sub: Subscription;

  constructor(private route: ActivatedRoute,
    private musicDetalhe: MusicasService) { }

    ngOnInit() {
      this.sub = this.route.params.subscribe(params => {
          this.minhaMusica = this.musicDetalhe.getTimeByName(params['minhaMusica']);

      });
  }

  ngOnDestroy() {

      this.sub.unsubscribe();
  }

} 

