import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exercicio5',
  templateUrl: './exercicio5.component.html',
  styleUrls: ['./exercicio5.component.css']
})
export class Exercicio5Component implements OnInit {

  senhauser: any;
  loginuser:  any; 
  constructor(){} 

  mostrar(){

      console.log();
      alert('Dados Invalidos');

      }
      validarLogin () {
        console.log(this.loginuser);
        if  (!this.loginuser.match('[a-zA-Z]')) {
        alert('Verifique o campo novamente');
        }
        }
        validarSenha() {
        console.log(this.senhauser);
        if  (!this.senhauser.match('^(?=.*[0-9])(?=.*[a-z])(?=.*[@#$%^&+=.\-_*])([a-zA-Z0-9@#$%^&+=*.\-_]){3,}$')) {
        alert('Verifique o campo novamente');
        }
        }

  ngOnInit() {  }
}

