import { Component, OnInit, Input, Output,EventEmitter } from '@angular/core';


@Component({
  selector: 'app-rpg-filho',
  templateUrl: './rpg-filho.component.html',
  styleUrls: ['./rpg-filho.component.css']
})
export class RpgFilhoComponent implements OnInit {

@Input() vida: number;
@Output() eventoMorte = new EventEmitter;
danoinformado: number;
morreu: boolean;


dano() {	
if (this.vida - this.danoinformado > 0) {
let danotomado = this.vida - this.danoinformado;
this.vida = danotomado;
} else {
this.vida = 0;
this.morreu = true;
this.eventoMorte.emit(this.morreu);

}


console.log(this.vida);

}
  constructor() { }

  ngOnInit() {
  }

}
