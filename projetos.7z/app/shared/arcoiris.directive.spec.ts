import { ArcoirisDirective } from './arcoiris.directive';

describe('ArcoirisDirective', () => {
  it('should create an instance', () => {
    const directive = new ArcoirisDirective ();
    expect(directive).toBeTruthy();
  });
});
