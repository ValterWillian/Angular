import { Component, OnInit, Input, Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-botoes',
  templateUrl: './botoes.component.html',
  styleUrls: ['./botoes.component.css']
})
export class BotoesComponent {

    tamanho : number=10;

  aumentarLetra() {
  
    let tamanhoNovo = this.tamanho + 2;
      this.tamanho = tamanhoNovo ;
  
  }

  dimininurLetra() {

    let tamanhoNovo = this.tamanho - 2;
    this.tamanho = tamanhoNovo ;

}
  constructor() { }


}
