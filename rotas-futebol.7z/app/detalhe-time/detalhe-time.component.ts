import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detalhe-time',
  templateUrl: './detalhe-time.component.html',
  styleUrls: ['./detalhe-time.component.css']
})
export class DetalheTimeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
