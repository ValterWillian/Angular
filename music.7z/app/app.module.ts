
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { MaterializeModule } from 'angular2-materialize';
import { routing } from './app.routing';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { ListaComponent } from './lista/lista.component';
import { MusicasService } from './musicas.service';
import { MusicasComponent } from './musicas/musicas.component';
import { DetalheMusicaComponent } from './detalhe-musica/detalhe-musica.component';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ListaComponent,
    MusicasComponent,
    DetalheMusicaComponent
  ],
  imports: [
    BrowserModule,
    routing
  ],
  providers: [MusicasService],
  bootstrap: [AppComponent]
})
export class AppModule { }
