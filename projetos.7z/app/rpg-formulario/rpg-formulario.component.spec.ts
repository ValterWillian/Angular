import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RpgFormularioComponent } from './rpg-formulario.component';

describe('RpgFormularioComponent', () => {
  let component: RpgFormularioComponent;
  let fixture: ComponentFixture<RpgFormularioComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RpgFormularioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RpgFormularioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
