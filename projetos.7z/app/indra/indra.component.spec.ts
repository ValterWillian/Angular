import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IndraComponent } from './indra.component';

describe('IndraComponent', () => {
  let component: IndraComponent;
  let fixture: ComponentFixture<IndraComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IndraComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IndraComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
