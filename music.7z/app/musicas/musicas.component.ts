import { MusicasService } from './../musicas.service';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { ActivatedRoute } from '@angular/router';
import { Musica } from '../musica';

@Component({
  selector: 'app-musicas',
  templateUrl: './musicas.component.html',
  styleUrls: ['./musicas.component.css']
})
export class MusicasComponent implements OnInit {

 
  
  novamusica : Musica;

  constructor(private servico : MusicasService) { }


     
addmusica(id, nome, ano, genero, artista) {
this.novamusica = { id: id, nome: nome, artista: artista, genero: genero, ano: ano,};
this.servico.addMusicas(this.novamusica);


  }
  ngOnInit() {

  }

}
