import { Injectable } from '@angular/core';
import { Musica } from './musica';

@Injectable()
export class MusicasService {

  musicas: Musica [] = [
    {
    id: 1 ,
    nome: 'The Old Monsters (Mash Up Remake)',
    artista: 'Astrix',
    genero: 'PsyTrance',
    ano: 2016
    
    },
    {
      id: 2 ,
      nome: 'Lift Me Up',
      artista: 'Sesto Sento',
      genero: 'PsyTrance',
      ano: 2009
    },
    
    {
      id: 3 ,
      nome: 'Mysterious Ways',
      artista: 'Sesto Sento',
      genero: 'PsyTrance',
      ano: 2008
    
      }
    ];
    
    getMusicas () {
    
      return this.musicas;
    }

    addMusicas (musica) {
      this.musicas.push(musica);
    }

    getTimeByName(nome: string): Musica {
      for (let i in this.musicas) {
  
        if (nome == this.musicas[i].nome) {
          return this.musicas[i];
        }
      }}

  constructor() { }

}
