import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vida-neto',
  templateUrl: './vida-neto.component.html',
  styleUrls: ['./vida-neto.component.css']
})
export class VidaNetoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
