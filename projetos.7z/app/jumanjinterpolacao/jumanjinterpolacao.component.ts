import { Component } from '@angular/core';

@Component({
  selector: 'app-jumanjinterpolacao',
  templateUrl: './jumanjinterpolacao.component.html',
  styleUrls: ['./jumanjinterpolacao.component.css']
})
export class JumanjinterpolacaoComponent {
  varia = true;
  sexo: string;
  classe = 'apresentacao';
  constructor() {

  }

  boasvindas(): string {


    if (this.sexo == 'Masculino') {

      return ('Bem vindo');
    } else if (this.sexo == 'Feminino') {

      return ('Bem vinda');
    }

  }
  pegarValor(sexo) {
    this.sexo = sexo;
  }
  enviar() {

    this.classe = '';
  }

}
