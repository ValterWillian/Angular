import { Component, OnInit } from '@angular/core';
import { CadastroService } from 'app/cadastro.service';
import { Pessoa } from 'app/Pessoa';

@Component({
  selector: 'mt-corrida',
  templateUrl: './corrida.component.html',
  styleUrls: ['./corrida.component.css']
})
export class CorridaComponent implements OnInit {

pessoa:Pessoa;

  nomePassageiro: string 
  sobrenomePassageiro: string;
  cpfPassageiro: number;
  emailPassageiro: String;
  telefonePassageiro: number;
  localizacao:string;
  confirmaLocaliza: Boolean =false;
  confirmaMotorista: Boolean = false;
  nomeMotorista : string;
  telefoneMotorista: number;
  carro:string

  constructor( private servico: CadastroService) {  }


  confirmaDestino(destino){

    this.localizacao = destino;
    this.pessoa = this.servico.pessoa;
    this.nomePassageiro = this.pessoa.nome;
    this.sobrenomePassageiro = this.pessoa.sobrenome;
   this.cpfPassageiro = this.pessoa.cpf;
   this.emailPassageiro = this.pessoa.email;
   this.telefonePassageiro = this.pessoa.telefone;
   this.confirmaLocaliza = true;
 

  }

  iniciaCorrida(destino){

    this.confirmaMotorista = true;
    this.nomeMotorista = this.servico.motorista.nome;
    this.telefoneMotorista = this.servico.motorista.telefone;
    this.carro = this.servico.motorista.Nomedocarro;
    this.localizacao = destino;
  }
  

  ngOnInit() {





  }

}
