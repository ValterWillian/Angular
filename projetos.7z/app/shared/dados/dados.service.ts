import { Injectable } from '@angular/core';


@Injectable()
export class DadosService {
  
  lados;
  valor;
  escolha;
  
  dados4() {
  this.lados = 4;
  this.valor = 1;
  
  this.valor = Math.floor(Math.random() * 4) + 1;
  return this.valor;
  }
  dados6() {
  this.lados = 6;
  this.valor = 1;
  
  this.valor = Math.floor(Math.random() * 6) + 1;
  return this.valor;
  }
  dados10() {
  this.lados = 10;
  this.valor = 1;
  
  this.valor = Math.floor(Math.random() * 10) + 1;
  return this.valor; 
  }
  dados12() {
  this.lados = 12;
  this.valor = 1;
  
  this.valor = Math.floor(Math.random() * 12) + 1;
  return this.valor;
  }
  dados20() {
  this.lados = 20;
  this.valor = 1;
  
  this.valor = Math.floor(Math.random() * 20) + 1;
  return this.valor;
  }
  dados100() {
  this.lados = 100;
  this.valor = 1;
  
  this.valor = Math.floor(Math.random() * 100) + 1;
  return this.valor;
  }} 
  

