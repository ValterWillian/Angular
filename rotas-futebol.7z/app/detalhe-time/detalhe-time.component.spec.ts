import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetalheTimeComponent } from './detalhe-time.component';

describe('DetalheTimeComponent', () => {
  let component: DetalheTimeComponent;
  let fixture: ComponentFixture<DetalheTimeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetalheTimeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetalheTimeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
